<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

//Route Hooks - Do not delete//
	Route::view('estudiantes', 'livewire.estudiantes.index')->middleware('auth');
	Route::view('cursos', 'livewire.cursos.index')->middleware('auth');
	Route::view('instructors', 'livewire.instructors.index')->middleware('auth');
	Route::view('vehiculos', 'livewire.vehiculos.index')->middleware('auth');
	Route::view('tenants', 'livewire.tenants.index')->middleware('auth');
	Route::view('users', 'livewire.users.index')->middleware('auth');
	Route::view('estadolicenciainstructors', 'livewire.estadolicenciainstructors.index')->middleware('auth');
	Route::view('estadomantenimientos', 'livewire.estadomantenimientos.index')->middleware('auth');
	Route::view('estadovehiculos', 'livewire.estadovehiculos.index')->middleware('auth');
	Route::view('permisos', 'livewire.permisos.index')->middleware('auth');
	Route::view('modulos', 'livewire.modulos.index')->middleware('auth');
	Route::view('rols', 'livewire.rols.index')->middleware('auth');