<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php if (! empty(trim($__env->yieldContent('title')))): ?> <?php echo $__env->yieldContent('title'); ?> | <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?> <?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</head>
<body>
    <div id="app" class="d-flex flex-column min-vh-100">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                <a class="navbar-brand" href="<?php echo e(url('/home')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->guest()): ?>
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
					<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                    <ul class="navbar-nav mr-auto">
						<!--Nav Bar Hooks - Do not delete!!-->
						<li class="nav-item">
                            <a href="<?php echo e(url('/estudiantes')); ?>" class="nav-link"><i class="bi-house text-info"></i> Estudiantes</a> 
                        </li>
						<li class="nav-item">
                            <a href="<?php echo e(url('/cursos')); ?>" class="nav-link"><i class="bi-journal-bookmark-fill text-info"></i> Cursos</a> 
                        </li>
						<li class="nav-item">
                            <a href="<?php echo e(url('/instructors')); ?>" class="nav-link"><i class="bi-person-badge-fill text-info"></i> Instructores</a> 
                        </li>
						<li class="nav-item">
                            <a href="<?php echo e(url('/vehiculos')); ?>" class="nav-link"><i class="bi-car-front-fill text-info"></i> Vehículos</a> 
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownEstados" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="bi-list-check text-info"></i> Estados
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdownEstados">
                                <li><a class="dropdown-item" href="<?php echo e(url('/estadolicenciainstructors')); ?>">Estado licencia instructores</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(url('/estadomantenimientos')); ?>">Estado mantenimientos</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(url('/estadovehiculos')); ?>">Estado vehiculos</a></li>
                            </ul>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownConfig" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="bi-gear-fill text-info"></i> Configuración
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdownConfig">
                                <li><a class="dropdown-item" href="<?php echo e(url('/users')); ?>">Usuarios</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(url('/permisos')); ?>">Permisos</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(url('/modulos')); ?>">Modulos</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(url('/rols')); ?>">Roles</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(url('/tenants')); ?>">Clientes</a></li>
                            </ul>
                        </li>
                    </ul>
					<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->guest()): ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->nombres); ?> <?php echo e(Auth::user()->apellidos); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4 flex-grow-1">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        
        <footer class="footer mt-auto py-3 bg-light text-center border-top">
            <div class="container">
                <span class="text-muted small"><b>CEA Web</b> con la tecnología de <a href="https://edgasanc.com" target="_blank" class="text-decoration-none fw-bold text-muted">EDGASANC.COM</a><br>Derechos Reservados <?php echo e(date('Y')); ?></span>
            </div>
        </footer>
    </div>
    <script type="module">
        window.addEventListener('closeModal', () => {
            bootstrap.Modal.getInstance(document.getElementById('DataModal')).hide();
        })
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH /var/www/cea.edgasanc.com/cea/resources/views/layouts/app.blade.php ENDPATH**/ ?>